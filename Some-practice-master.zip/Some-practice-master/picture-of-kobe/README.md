## css画的科比画像

好吧好像画的对不起唠嗑，有时间把脚补上。

![kobe](http://o9r9kpwmc.bkt.clouddn.com/worker/some-practice/kobe.png)